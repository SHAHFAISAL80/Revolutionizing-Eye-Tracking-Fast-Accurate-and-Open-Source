// compile additional guids

#define INITGUID
#include <guiddef.h>

#include "DirectShowGuids.h"



